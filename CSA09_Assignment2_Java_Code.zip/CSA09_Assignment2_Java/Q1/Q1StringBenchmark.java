public class Q1StringBenchmark {
    static String usingPlus(int fields) {
        String result = "";
        for (int i = 0; i < fields; i++) result += "FIELD" + i + "|";
        return result;
    }
    static String usingBuilder(int fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields; i++) sb.append("FIELD").append(i).append('|');
        return sb.toString();
    }
    static String usingBuffer(int fields) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < fields; i++) sb.append("FIELD").append(i).append('|');
        return sb.toString();
    }
    static long time(Runnable task, int repeats) {
        long start = System.nanoTime();
        for (int i = 0; i < repeats; i++) task.run();
        return (System.nanoTime() - start) / repeats;
    }
    public static void main(String[] args) {
        int fields = 50, repeats = 200;
        String a = usingPlus(fields), b = usingBuilder(fields), c = usingBuffer(fields);
        System.out.println("Railway e-Ticket Text Benchmark");
        System.out.println("Fields per ticket: " + fields + ", repetitions: " + repeats);
        System.out.println("All outputs equal: " + (a.equals(b) && b.equals(c)));
        System.out.println("String + average ns: " + time(() -> usingPlus(fields), repeats));
        System.out.println("StringBuilder average ns: " + time(() -> usingBuilder(fields), repeats));
        System.out.println("StringBuffer average ns: " + time(() -> usingBuffer(fields), repeats));
        System.out.println("Recommendation: StringBuilder per ticket; StringBuffer for shared synchronized log.");
    }
}

import java.util.*;
public class Q2CollectionComparison {
    static long measure(Runnable r) {
        long start = System.nanoTime(); r.run(); return System.nanoTime() - start;
    }
    public static void main(String[] args) {
        int[] sizes = {1000, 5000, 10000};
        System.out.println("Playlist Collection Comparison");
        for (int n : sizes) {
            ArrayList<Integer> a = new ArrayList<>();
            LinkedList<Integer> l = new LinkedList<>();
            for (int i=0; i<n; i++) { a.add(i); l.add(i); }
            long arrayGet = measure(() -> { for(int i=0;i<1000;i++) a.get(n/2); });
            long linkedGet = measure(() -> { for(int i=0;i<1000;i++) l.get(n/2); });
            long arrayFront = measure(() -> { a.add(0,-1); a.remove(0); });
            long linkedFront = measure(() -> { l.addFirst(-1); l.removeFirst(); });
            System.out.println("n=" + n + " ArrayList get(1000x)=" + arrayGet +
                "ns LinkedList get(1000x)=" + linkedGet + "ns");
            System.out.println("   front add/remove ArrayList=" + arrayFront +
                "ns LinkedList=" + linkedFront + "ns");
        }
        ArrayDeque<String> upNext = new ArrayDeque<>();
        upNext.addFirst("Urgent Song"); upNext.addLast("Next Song");
        System.out.println("ArrayDeque Up Next: " + upNext);
        System.out.println("Choice: ArrayList for indexed playlists; ArrayDeque for both-end queue operations.");
    }
}

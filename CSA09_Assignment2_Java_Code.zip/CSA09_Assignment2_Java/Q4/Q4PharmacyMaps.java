import java.util.*;
public class Q4PharmacyMaps {
    public static void main(String[] args) {
        Map<String,Integer> hash = new HashMap<>();
        Map<String,Integer> sorted = new TreeMap<>();
        Map<String,Integer> insertion = new LinkedHashMap<>();
        String[][] data = {{"MED103","25"},{"MED101","40"},{"MED102","15"}};
        for (String[] row : data) {
            int stock = Integer.parseInt(row[1]);
            hash.put(row[0], stock);
            sorted.put(row[0], stock);
            insertion.put(row[0], stock);
        }
        System.out.println("Stock lookup MED101: " + hash.get("MED101"));
        System.out.println("HashMap order: " + hash.keySet());
        System.out.println("TreeMap code order: " + sorted.keySet());
        System.out.println("LinkedHashMap insertion order: " + insertion.keySet());
        System.out.println("Recommendation: HashMap for lookup; TreeMap for sorted report; LinkedHashMap for entry order.");
    }
}

import java.util.*;
public class Q7RedesignValidation {
    static class Medicine {
        final String code; final int stock;
        Medicine(String code, int stock) { this.code = code; this.stock = stock; }
    }
    public static void main(String[] args) {
        List<Medicine> original = new ArrayList<>();
        Map<String,Medicine> redesigned = new HashMap<>();
        for (int i=1; i<=10000; i++) {
            Medicine m = new Medicine(String.format("MED%05d", i), i % 100);
            original.add(m);
            redesigned.put(m.code, m);
        }
        String target = "MED09999";
        long start1 = System.nanoTime();
        Medicine found1 = null;
        for (Medicine m : original) if (m.code.equals(target)) { found1 = m; break; }
        long listTime = System.nanoTime() - start1;

        long start2 = System.nanoTime();
        Medicine found2 = redesigned.get(target);
        long mapTime = System.nanoTime() - start2;

        System.out.println("Redesign: linear list lookup -> HashMap lookup");
        System.out.println("Records: " + original.size());
        System.out.println("List result: " + (found1 == null ? "not found" : found1.code));
        System.out.println("HashMap result: " + (found2 == null ? "not found" : found2.code));
        System.out.println("List lookup ns: " + listTime);
        System.out.println("HashMap lookup ns: " + mapTime);
        System.out.println("Expected complexity: List O(n); HashMap average O(1).");
        System.out.println("Trade-off: HashMap uses extra memory and does not preserve sorted order.");
    }
}

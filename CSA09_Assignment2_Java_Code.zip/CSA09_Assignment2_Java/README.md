# CSA09 Programming in Java – Assignment 2
Seven Java examples aligned with Q1–Q7 of the supplied assignment.

## Compile and run
Run each command from its question folder:
- Q1: `javac Q1StringBenchmark.java && java Q1StringBenchmark`
- Q2: `javac Q2CollectionComparison.java && java Q2CollectionComparison`
- Q3: `javac Attendance.java && java Attendance`
- Q4: `javac Q4PharmacyMaps.java && java Q4PharmacyMaps`
- Q5: `javac LeaderboardDemo.java && java LeaderboardDemo`
- Q6: `javac Triage.java && java Triage`
- Q7: `javac Q7RedesignValidation.java && java Q7RedesignValidation`

These are runnable starter implementations. The assignment also requires written analysis, multiple controlled experiments, repeated/averaged measurements, raw data, and a defended redesign. Do not present the sample timing values as universal results; run on your own laptop and record your own measurements.
